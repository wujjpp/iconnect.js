'use strict';

/**
 * @ngdoc service
 * @name iconnectApp.Currency/Converter
 * @description
 * # Currency/Converter
 * Factory in the iconnectApp.
 */
angular.module('iconnectApp')
  .factory('Currency/Converter', function () {
    // Service logic
    // ...

    var meaningOfLife = 'Test';

    // Public API here
    return {
      someMethod: function () {
        return meaningOfLife;
      }
    };
  });
