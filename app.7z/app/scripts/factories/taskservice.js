'use strict';

/**
 * @ngdoc service
 * @name iconnectApp.TaskService
 * @description
 * # taskService
 * Factory in the iconnectApp.
 */
angular.module('iconnectApp')
  .factory('TaskService', ['$resource', function ($resource) {
    return $resource('/api/tasks/:id', null, {
      'update': {method: 'PUT'}
    });
  }]);
