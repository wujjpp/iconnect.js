'use strict';

/**
 * @ngdoc overview
 * @name iconnectApp
 * @description
 * # iconnectApp
 *
 * Main module of the application.
 */
var App = angular
  .module('iconnectApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ui.router'
  ]);

App.config(function($stateProvider, $urlRouterProvider){

  // For any unmatched url, send to /route1
  $urlRouterProvider.otherwise("/");

  $stateProvider
    .state('home', {
      url: "/",
      templateUrl: 'views/main.html',
      controller: 'MainCtrl',
      controllerAs: 'main'
    })
    .state('route1', {
      url: "/about",
      templateUrl: 'views/about.html',
      controller: 'AboutCtrl',
      controllerAs: 'about'
    })
    .state('route2', {
      url:'/myRoute',
      templateUrl: 'views/myroute.html',
      controller: 'MyrouteCtrl',
      controllerAs: 'myRoute'
    });
});

