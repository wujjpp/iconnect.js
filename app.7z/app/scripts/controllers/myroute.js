'use strict';

/**
 * @ngdoc function
 * @name iconnectApp.controller:MyrouteCtrl
 * @description
 * # MyrouteCtrl
 * Controller of the iconnectApp
 */
angular.module('iconnectApp')
  .controller('MyrouteCtrl', function ($scope) {

    $scope.$on('$viewContentLoaded', function()
    {
      console.log('scope ctrl loaded');
    });

    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
