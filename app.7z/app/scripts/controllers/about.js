'use strict';

/**
 * @ngdoc function
 * @name iconnectApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the iconnectApp
 */
angular.module('iconnectApp')
  .controller('AboutCtrl', ['$scope', 'TaskService', function ($scope, Task) {

    $scope.$on('$viewContentLoaded', function()
    {
      console.log('about ctrl loaded');
    });

    var tasks = Task.query();
    $scope.tasks = tasks;

    //create task
    $scope.addTask = function () {
      //$scope.model.tasks.push($scope.todo);
      var task = new Task({taskName:$scope.task});
      task.$save(function(task){
        $scope.tasks.push(task);
      });
      $scope.task = '';
    };

    //update task
    $scope.updateTask = function (index) {
      var task = $scope.tasks[index];

      Task.update({id: task.id}, task, function(resTask){
        console.log('callback called');
        console.log(resTask);
      });
      //task.$update(function(resTask){
      //  task = resTask;
      //});
    };


    //delete data
    $scope.deleteTask = function (index) {
      var task = $scope.tasks[index];
      task.$delete({id: task.id}, function(){
        $scope.tasks.splice(index, 1);
      });
    };
  }]);
