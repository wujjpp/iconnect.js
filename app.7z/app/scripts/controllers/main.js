'use strict';

/**
 * @ngdoc function
 * @name iconnectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the iconnectApp
 */
angular.module('iconnectApp')
  .controller('MainCtrl', ['$scope', 'CurrencyConverter', 'Currency/Converter', function ($scope, currencyConverter, foo) {

    $scope.$on('$viewContentLoaded', function() {
      console.log('$viewContentLoaded');

      //Layout.init(); //  Init entire layout(header, footer, sidebar, etc) on page load if the partials included in server side instead of loading with ng-include directive
    });

    $scope.invoice = this;

    this.qty = 1;
    this.cost = 2;
    this.inCurr = 'EUR';
    this.currencies = currencyConverter.currencies;

    this.total = function total(outCurr) {
      return currencyConverter.convert(this.qty * this.cost, this.inCurr, outCurr);
    };
    this.pay = function pay() {
      window.alert("Thanks!");
    };

    console.log(foo.someMethod());

  }]);
